#ifndef __FLAGS_H
#define __FLAGS_H

#include "stm32f4xx.h"                  // Device header

extern u8 flag_start, flag_openmv_mode, flag_ops_ready, flag_run, flag_stable, flag_arrive;

#endif
