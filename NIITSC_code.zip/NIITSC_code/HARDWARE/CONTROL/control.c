#include "control.h"
#include "motor.h"
#include "encoder.h"
#include "sys.h"
#include "stdlib.h"
#include "ops.h"
#include "delay.h"
#include "math.h"
#include "flags.h"

float stable_threshold = 40;

int check_stable()
{
	float cur_x = OPS_x, cur_y = OPS_y, cur_heading = OPS_heading;
	delay_ms(50);
	if (fabs(cur_x - OPS_x + cur_y - OPS_y + cur_heading - OPS_heading) > stable_threshold)
		return 0;
	else
		return 1;
	
}
