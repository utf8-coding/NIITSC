#ifndef BOOL_H_
#define BOOL_H_

typedef enum {
	false = 0, true = !false
}bool;

#endif
