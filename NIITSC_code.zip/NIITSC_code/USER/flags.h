#ifndef __FLAGS_H
#define __FLAGS_H

#include "stm32f4xx.h"                  // Device header

extern u8 flag_start;

#endif
