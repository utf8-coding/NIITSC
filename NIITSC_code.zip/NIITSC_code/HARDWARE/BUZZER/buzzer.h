#ifndef __BUZZER_H
#define __BUZZER_H

//#define BEEP PDout(10)	// PD10  =1����     =0:��

void BUZZER_Init(void);
void BUZZER_Sec(float time_sec);
void BUZZER_Ms(void);
#endif
