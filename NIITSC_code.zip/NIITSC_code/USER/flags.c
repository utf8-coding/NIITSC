#include "stm32f4xx.h"                  // Device header
#include "flags.h"

u8 flag_start = 0;
