#include "flags.h"

u8 flag_start = 0, flag_openmv_mode = 0, flag_ops_ready = 0, flag_run = 0, flag_stable = 1, flag_arrive = 0;
